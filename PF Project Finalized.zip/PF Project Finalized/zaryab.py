#  بِسمِ اللہِ الرَّحمٰنِ الرَّحِيم
'''_____________________________________'''
def info(name,roll_number,depart):
    with open("info.txt","a") as f:
        f.write(f"\nName:{name}\nRoll no.:{roll_number}\nDepartment:{depart}")
    
'''______________________________________'''
add1_total = 100
def round1():
    print("ROUND-1")
    add1_total = 100
    add1=0
    with open("r1.txt","r") as f :
        with open("w1.txt","r") as w:
            a=w.readlines()
            for i in range (3):
                for j in range(5):
                    print(f.readline())
                n=input("Enter your answer[a/b/c/d]:\t")
                if n in a[i]:
                    print("Your answer is correct")
                    add1+=100
                else:
                    print("Your answer is incorrect")
    print("Your total round-1 score: ",add1)
    return add1
'''______________________________________'''
add2_total = 100
def round2():
    print("ROUND-2")
    add2_total = 100
    add2=0
    with open("r2.txt","r") as f :
        with open("w2.txt","r") as w:
            a=w.readlines()
            for i in range (5):
                for j in range(5):
                    print(f.readline())
                n=input("Enter your answer[a/b/c/d]:\t")
                if n in a[i]:
                    print("Your answer is correct")
                    add2+=20
                else:
                    print("Your answer is incorrect")
    print("Your total round-2 score: ",add2)
    return add2

'''______________________________________'''
add3_total = 150
def round3():
    print("ROUND-3")
    add3=0
    with open("r3.txt","r") as f :
        with open("w3.txt","r") as w:
            a=w.readlines()
            for i in range (3):
                for j in range(5):
                    print(f.readline())
                n=input("Enter your answer[a/b/c/d]:\t")
                if n in a[i]:
                    print("Your answer is correct")
                    add3+=50
                else:
                    print("Your answer is incorrect")
    print("Your total round-3 score: ",add3)
    return add3
'''______________________________________'''
def result():
    with open("info.txt","r") as f:
        print(f.readline())
        
'''______________________________________'''

def score(x,y,z,a,b,c):
    final_score = x+y+z
    print("NAME:",a)
    print("ROLL # ",b)
    print("DEPARTMENT:",c)
    print("Your final score is ",final_score)
    
'''______________________________________'''

def program():
    print("------Welcome to Quiz Game------")
    a = input("Are you ready to play? [Yes/No]")
    if a.lower() == "yes":
        print("Enter your information")
        name = input("Enter your name:")
        roll_number = input("Enter your roll number: ")
        depart = input("Enter your department: ")
        info(name,roll_number,depart)
        print("Let's start!")
        a=round1()
        if ((a/add1_total)*100)>=70:
            b=round2()
            if ((b/add2_total)*100)>=80:
                c=round3()
                if c == add3_total:
                    print("Congratulation! :-)")
                    k = input("Press 'ENTER' to see your final score")
                    score(a,b,c,name,roll_number,depart)
                else:
                    print("Oops! You Are Disqualify. Better Luck Next Time :( ")
            else:
                    print("Oops! You Are Disqualify. Better Luck Next Time :( ")
        else:
                print("Oops! You Are Disqualify. Better Luck Next Time :( ")
    else:
        print(" Bye Bye! ")
              
'''______________________________________'''

# now calling the whole program here!
print(program())
print("ALLAH HAFIZ")